This directory has no configuration on purpose.
